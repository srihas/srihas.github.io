#!/bin/bash

#source ../.bash.utils

SEL_DIR=$1
FILE_PATTERN=$2

options=()
files_to_patch_str=""

menu() {
    clear
    echo "-------------------------------------------------------------"
    print_in_blue " Select files to patch    \n"
    echo "-------------------------------------------------------------"
    print_in_blue "Avaliable options:\n"
    for i in ${!options[@]}; do 
        printf "%3d%s) %s\n" $((i+1)) "${choices[i]:- }" "${options[i]}"
    done
    if [[ "$msg" ]]; then echo "$msg"; fi
}

function show_menu() {
    printf "\n"
    prompt="$yellow Check an option (again to uncheck, ENTER when done):$reset "
    while menu && read -rp "$prompt" num && [[ "$num" ]]; do
        [[ "$num" != *[![:digit:]]* ]] &&
        (( num > 0 && num <= ${#options[@]} )) ||
        { msg="Invalid option: $num"; continue; }
        ((num--)); msg="${options[num]} was ${choices[num]:+un}checked"
        [[ "${choices[num]}" ]] && choices[num]="" || choices[num]="+"
    done

    printf "You selected"; msg=" nothing"
    declare -a result_arr=()
    for i in ${!options[@]}; do 
        [[ "${choices[i]}" ]] && { result_arr+=("${options[i]}"); print_in_green " ${options[i]}"; msg=""; }
    done
    echo "$msg"

    LOG DEBUG "Printing selected vals [${#result_arr[@]}]"
    for i in ${#result_arr[@]};do
	printf " %s" "${result_arr[i]}"
    done

    if [ "$msg" != " nothing" ];then
        files_to_patch_str=$( IFS='|'; echo "${result_arr[*]}" );
	return 0
    else
	return 1
    fi
}

function main() {
    LOG DEBUG "Arguments: $#"
    if [ $# -lt 2 ];then
	return 1
    fi

    local dir_path=$(realpath $SEL_DIR)
    if [ ! -d $dir_path ];then
        print_in_red "Directory [$SEL_DIR] is invalid\n"
        return 1
    fi
    
    LOG INFO "Listing the files from [$dir_path] for pattern: [$FILE_PATTERN]"
    declare -a files=()
    tmp_output=$(get_files_from_dir $dir_path $FILE_PATTERN)
    LOG DEBUG "Printing tmp output: {$tmp_output}"
    tmp_files=$(getoutput "$tmp_output")
    IFS="|" read -a files <<< $tmp_files
    #is_array files && echo "Array" || echo "Not an array"
    LOG DEBUG "Files found from find is [${!files[@]}] : [${files[@]}]"
    declare -a files_arr=()
    declare -i count=0
    for file in ${files[@]};do
        LOG DEBUG "Found file[$count]: $file"
        count+=1
        file_name=$(get_file_name_from_path $file)
        options+=($file_name)
    done
    LOG DEBUG "Found files: [$count] in [$dir_path] for pattern: [$FILE_PATTERN]"
    LOG DEBUG "Updated options: [${#options[@]}]"
    show_menu
    if [ $? -eq 0 ];then
	LOG INFO "Selected files: [$files_to_patch_str]"
	output "$files_to_patch_str"
	return 1
    else
	LOG INFO "Exiting as no files selected"
        return 1
    fi
}

main $1 $2



\unset -f main
