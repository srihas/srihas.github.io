#!/bin/bash

DEST_DIR="$ODL_INSTALLATION_DIR"
CACHE_DIR="$DEST_DIR"/.cache

MAIN_DIR=${PWD}
BUILD_LOC=$1

if [ -z $2 ];then
    ODL_DIR=$(date +"%b%d%Y" | tr [:upper:] [:lower:])
else
    ODL_DIR=$2
fi

# echo $ODL_DIR
ODL_DIR_PATH="$DEST_DIR/$ODL_DIR"


# Functions

function setupOdl() {
    print_in_green "***********************Setting up Odl******************************\n\n"

    createOdlFolder $ODL_DIR
    
    if copyBuild $BUILD_LOC; then
        print_in_green "Proceeding to extract contents\n"
        if extractContents; then
	    if installPackages; then
		if configProperties;then
		    print_in_green "Setup successfull\n"
		    return 0;
		else
		    print_in_red "Failed to configure ODL installation\n"
		fi
	    else
		print_in_red "ODL package could not be installed\n"
	    fi
	else
	    print_in_red "Extracting build failed\n"
        fi
    else
        print_in_red "Exiting as copy build failed\n"
    fi

    return 1;
}

function createOdlFolder() {
    local ODL_DIR_LOCAL="$1"
    print_in_green "Setting up ODL in path: `pwd`/$ODL_DIR_LOCAL\n"
    if [ -d "$ODL_DIR_LOCAL" ];
    then
	if [ "$(ls -A $ODL_DIR_LOCAL)" ];then
	    ask "ODL directory exists at `pwd`/$ODL_DIR_LOCAL, overwrite? (y/n): "
	    if answer_is_yes; then
                print_in_red "Deleting the directory : `pwd`/$ODL_DIR_LOCAL\n"
                rm -rf $ODL_DIR_LOCAL
		mkdir $ODL_DIR_LOCAL
            fi
        fi
    else
        mkdir $ODL_DIR_LOCAL
    fi
    echo ""
}


function getHash() {
    cksum <<<"$1"| cut -f 1 -d ' '
}

function copyBuild() {
    print_in_red "************************Copying build****************************\n"

    if [ ! -d $CACHE_DIR ];then
        mkdir $CACHE_DIR
    fi
    local BUILD_LOC_LOCAL=$1
    TMP_DIR=$(getHash "$BUILD_LOC_LOCAL")
    #echo "$TMP_DIR - tmp directory"
    # Create a temp dir for copying latest tar gz
    TMP_DIR_PATH=$CACHE_DIR/$TMP_DIR

    if [ -d $TMP_DIR_PATH ] && [ "$(ls -A $TMP_DIR_PATH)" ]; then
        print_in_yellow "Cache directory already exists\n"
	print_in_yellow "Skipping copying build as cache exists\n"
	return;
    else 
        print_in_green "Creating tmp directory @ $TMP_DIR_PATH\n"
        mkdir -p $TMP_DIR_PATH
    fi

    ask 'SIGNUM: '
    local USERNAME="$(get_answer)"
    print_in_green "Executing command: scp $USERNAME@$BUILD_LOC_LOCAL/ERIC-ODL-DEB* $TMP_DIR_PATH\n\n\n"
    scp $USERNAME@$BUILD_LOC_LOCAL/ERIC-ODL-DEB* $TMP_DIR_PATH
}

function extractContents() {
    print_in_red "************************Extract build contents****************************\n"
    if [ -d $ODL_DIR ] && [ "$(ls -A $ODL_DIR)" ]; then
	print_in_red "ODL dir already exists : \n"
	print_in_yellow "-----------------------------------------------------------------------------\n"
	ls -ahl $ODL_DIR
	print_in_yellow "-----------------------------------------------------------------------------\n"
	ask "Extract to overwrite (y/n)? : "
        if ! answer_is_yes;then
	    print_in_yellow "Skipping extraction of build contents\n"
            return 0;
	fi
    fi
    print_in_green "Extracting file \"$TMP_DIR_PATH/ERIC-ODL-DEB*.tar.gz\" into \"`pwd`/$ODL_DIR\"\n"
    print_in_yellow "-----------------------------------------------------------------------------\n"
    tar -xvf $TMP_DIR_PATH/ERIC-ODL-DEB*.tar.gz -C $ODL_DIR;
    local STATUS=$?
    print_in_yellow "-----------------------------------------------------------------------------\n"
    return $STATUS;
}

function installPackages() {
    print_in_red "************************Installing package****************************\n"
    cd $ODL_DIR;
    local eric_odl_files=($(find . -type f -iname "eric-odl*.deb"))
    if [ ${#eric_odl_files[@]} -gt 1 ]; then
        print_in_red "Multiple Files found:\n ${eric_odl_files[*]}\n"
        ERIC_ODL_DEB_FILE=""
	while [ -z "$ERIC_ODL_DEB_FILE" ];do
	    ask "The deb package file to install: "
	    ERIC_ODL_DEB_FILE="$(get_answer)"
	done

    else
        ERIC_ODL_DEB_FILE=${eric_odl_files[0]}
    fi

    ask "Proceed with installing package: $ERIC_ODL_DEB_FILE? (y/n): "
    if ! answer_is_yes; then
	print_in_red "Exiting without installing package\n"
        return 1;
    fi
    print_in_green "Installing package: $ERIC_ODL_DEB_FILE\n"
    print_in_green "Extracting file $ERIC_ODL_DEB_FILE into odl\n"
    dpkg -x $ERIC_ODL_DEB_FILE odl
    if [ $? -eq 0 ];then
    	print_in_green "Installed package: $ERIC_ODL_DEB_FILE successfully\n"
        return 0;
    else
	print_in_red "Failed installing package: $ERIC_ODL_DEB_FILE\n"
        return 1;
    fi
}

function configProperties() {
    print_in_red "************************Configuring properties****************************\n"
    cd odl/opt/sdnc/opendaylight/bin
    print_in_green "\nUpdating JAVA_MAX_MEM from 2GB to 4GB in file: `pwd`/setenv\n"
    sed -i 's/2048m/4096m/g' setenv
    print_in_green "Updated JAVA_MAX_MEM successfully\n"
}

function st ()
{
    SERVICE="karaf";
    if pgrep -x "$SERVICE" > /dev/null; then
        "$ODL_HOME"/odl/opt/sdnc/opendaylight/bin/client -p Ericsson1234 showsvcstatus;
    else
        echo "Karaf is not running";
    fi
}


function start ()
{
    if [ $# -eq 0 ] && [ ! -z "$ODL_HOME" ];then
    	"$ODL_HOME"/odl/opt/sdnc/opendaylight/bin/start;
    elif [ $# -eq 1 ] && [ -f $1/odl/opt/sdnc/opendaylight/bin/start ];then
	$1/odl/opt/sdnc/opendaylight/bin/start;
    else
	print_in_red "ODL_HOME not set or pass ODL folder as argument\n"
        return 1;
    fi

    printf "Starting ODL: %s\n" "$ODL_FOLDER";
    while true; do
        sleep 8;
        st < /dev/null 2>&1 > /dev/null;
        if [ $? -eq 0 ]; then
            break;
        fi;
    done;
    echo "ODL is up, wait for bundles to load";
    while true; do
        sleep 1;
        st | grep --color=auto true;
        if [ $? -eq 0 ]; then
            break;
        fi;
        printf ".";
    done;
    printf "\n";
    echo "Status: ";
    st
}



ask() {
    print_question "$1"
    read -r
}

get_answer() {
    printf "%s" "$REPLY"
}

answer_is_yes() {
    [[ "$REPLY" =~ ^[Yy]$ ]] \
        && return 0 \
        || return 1
}

answer_is_not_empty() {
    if [ -z "$REPLY" ]; then
        return 0;
    else
        return 1;
    fi
}

print_question() {
    print_in_yellow " [?] $1"
}

print_in_yellow() {
    print_in_color "$1" 3
}

print_in_red() {
    print_in_color "$1" 1
}

print_in_green() {
    print_in_color "$1" 2
}

print_in_blue() {
    print_in_color "$1" 7
}

print_in_color() {
    printf "%b" \
        "$(tput setaf "$2" 2> /dev/null)" \
        "$1" \
        "$(tput sgr0 2> /dev/null)"
}


function clearCache() {
   print_in_green "Clearing tmp directories - $TMP_DIR_PATH\n"
   rm -rf $TMP_DIR_PATH
   print_in_green "Cleared cache successfully\n"
}

# Main function definition
function main() {
    setupOdl
    STATUS=$?
    ask "Clear cache(y/n)? : "
    if answer_is_yes; then
        clearCache
    else
        print_in_yellow "Skipping clear cache\n"
    fi
    return $STATUS;
}

# Main function call done here
cd $DEST_DIR

if main; then
    print_in_green "****************************Successfully installed ODL package************************\n"
    echo ""
    ask "Update ODL version in environment? (y/n): "
    if answer_is_yes; then
	sed -ir "s/^export*\s*ODL_FOLDER=.*/export ODL_FOLDER='$ODL_DIR'/" $ODL_CONFIG_FILE;
        val=sed -rn 's|.*ODL_FOLDER=([^\n]+)$|\1|p' $ODL_CONFIG_FILE
        if [ $val = $ODL_DIR ];then
	    print_in_green "Updated ODL version in environment successfully.\n"
            print_in_green "Reload profile\n"
	    print_in_green "********************************End******************************************\n"
	fi
    fi
else
    print_in_red "**************************Failed installing ODL package*******************************\n"
fi

# Navigate to newly setup ODL directory"
#echo $MAIN_DIR
cd $MAIN_DIR
cd $ODL_DIR_PATH

# Unset unsed variables
unset TMP_DIR_PATH
unset ODL_DIR
unset main
unset clearCache
unset TMP_DIR
unset configProperties
unset extractContents
unset copyBuild
unset getHash
unset createOdlFolder
