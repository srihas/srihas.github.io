#!/bin/bash

main() {
    if [ $# -eq 0 ];then
        print_in_red "Pass patch directory as an argument\n"
        return 1
    fi

    local patch_dir=$1
    local patch_dir_path=$(realpath $patch_dir)
    if [ -d $patch_dir_path ];then
        print_in_red "Directory [$patch_dir] is invalid\n"
        return 1
    fi

    # Identify the artifacts to be patched
    print_in_green "Proceeding to patch the artifacts from $patch_dir\n"
}

main

\unset -f main


